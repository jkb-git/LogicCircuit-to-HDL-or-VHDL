﻿using System;

namespace LogicCircuit.DataPersistent {
	public enum SnapTableAction {
		Insert,
		Delete,
		Update
	}
}
