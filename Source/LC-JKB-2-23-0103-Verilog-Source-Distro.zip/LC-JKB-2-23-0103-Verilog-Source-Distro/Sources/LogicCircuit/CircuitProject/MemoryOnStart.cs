﻿using System;

namespace LogicCircuit {
	public enum MemoryOnStart {
		Random,
		Zeros,
		Ones,
		Data
	}
}
