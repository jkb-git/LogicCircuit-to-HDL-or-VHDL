﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace LogicCircuit
{
	/// <summary>
	/// Interaction logic for DialogMemoryEditor.xaml
	/// </summary>
	public abstract partial class DialogMemoryEditor : Window
	{
		[SuppressMessage("Microsoft.Maintainability", "CA1500:VariableNamesShouldNotMatchFieldNames", MessageId = "addressBitWidth")]
		[SuppressMessage("Microsoft.Maintainability", "CA1500:VariableNamesShouldNotMatchFieldNames", MessageId = "dataBitWidth")]
		// jkb
		// add the ability to read .hack files into ROM
		private void ButtonLoadClick(object sender, RoutedEventArgs e)
		{
			try
			{
				FileStream stream;
				StreamReader file;
				OpenFileDialog dialog = new OpenFileDialog();

				dialog.InitialDirectory = Mainframe.IsDirectoryPathValid(this.openFileFolder.Value) ? this.openFileFolder.Value : Mainframe.DefaultProjectFolder();
				bool? result = dialog.ShowDialog(this);
				if (result.HasValue && result.Value)
				{
					this.openFileFolder.Value = Path.GetDirectoryName(dialog.FileName);
					int addressBitWidth = this.AddressBitWidth;
					int dataBitWidth = this.DataBitWidth;
					byte[] buffer = new byte[Memory.BytesPerCellFor(dataBitWidth)];
					int cellCount = Memory.NumberCellsFor(addressBitWidth);
					Tracer.Assert(cellCount * buffer.Length == this.data.Length);

					if (Path.GetExtension(dialog.FileName) == ".hack")
					{
						file = new StreamReader(Path.GetFullPath(dialog.FileName));
						stream = null;
					}
					else
					{
						stream = File.Open(dialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
						file = null;
					}
					for (int i = 0; i < cellCount; i++)
					{
						int readed = 0;
						if (file == null) // use the stream to parse an ordinary binary file
						{
							readed = stream.Read(buffer, 0, buffer.Length);
							if (readed <= 0)
							{
								Array.Clear(this.data, i * buffer.Length, this.data.Length - i * buffer.Length);
								break;
							}
						}
						else // stream is null; parse the hack character file
						{
							int bytes = 0;
							if (file.Peek() >= 0)
							{
								string binStr = file.ReadLine();
								int opcode = 0;
								UInt16 seed = 0x8000;
								int charIndex = 0;
								for (int j = 15; j >= 0; j--)
								{
									if (binStr[charIndex] == '1') opcode |= seed >> charIndex;
									charIndex++;
								}
								bytes += 2;
								readed = 2;
								buffer = BitConverter.GetBytes((UInt16)opcode);
								if (!BitConverter.IsLittleEndian) //Need this, depending upon Endianness
									Array.Reverse(buffer);
							}
							else if (bytes <= buffer.Length)
							{
								Array.Clear(this.data, i * buffer.Length, this.data.Length - i * buffer.Length);
								readed = 0;
								break;
							}
							int val = Memory.CellValue(buffer, Math.Min(8 * readed, dataBitWidth), 0);
							Memory.SetCellValue(this.data, dataBitWidth, i, val);
						}
						int value = Memory.CellValue(buffer, Math.Min(8 * readed, dataBitWidth), 0);
						Memory.SetCellValue(this.data, dataBitWidth, i, value);
					}
					this.FunctionMemory = new MemoryEditor(this.data, addressBitWidth, dataBitWidth);
				}
			}
			catch (Exception exception)
			{
				App.Mainframe.ReportException(exception);
			}
		}
		// end jkb


	}
}