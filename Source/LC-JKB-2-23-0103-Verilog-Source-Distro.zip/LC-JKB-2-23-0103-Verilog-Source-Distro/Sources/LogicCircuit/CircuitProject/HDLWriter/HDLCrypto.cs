﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 *  
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System.Text;
using System.Linq;
// using Microsoft.Win32; // We use this library, but only explicitly to avoid ambiguity with System.Windows.Forms
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Diagnostics.CodeAnalysis;

namespace LogicCircuit
{
    public partial class CircuitProject
    {
        // These are used to encrypt certain information about the saved LC circuit to discourage use of on-line HDL N2T solutions.
        private static string HDLpublicKey;
        private static readonly UnicodeEncoding HDLencoder = new UnicodeEncoding();

        private static string HDLConvertDS(string plainText)
        {
            string cipherText = "";
            var rsa = new RSACryptoServiceProvider();
            // This public key was created on 1/15/2019 for use by John Bennett at the University of Colorado.
            // The companion private key is, well, private.
            // It uses the default key length of 1024.  If you want a longer key length, give RSACryptoServiceProvider()
            // an integer argument, e.g., "var rsa = new RSACryptoServiceProvider(2048);"
            // Longer key lengths will of course put more lines of fluff at the start of the HDL file.

            // Here is how you would create your own set of keys:
            // HDLprivateKey = rsa.ToXmlString(true);
            // HDLpublicKey = rsa.ToXmlString(false);
            // After you produce these keys you can temporarily insert them into
            // the output file by uncommenting the next two lines.
            // HDLOutFile.WriteLine("PublicKey = " + HDLpublicKey);
            // HDLOutFile.WriteLine("PrivateKey = " + HDLprivateKey);
            // If you want to verify the key length, uncomment the next line.
            // HDLOutFile.WriteLine("Key Length = " + rsa.KeySize.ToString());

            // Set our public key. This can be freely shared.
            HDLpublicKey = "<RSAKeyValue><Modulus>wyTWOojwfzQZtRDdGhB9XhXY2Xvedn5HIi+oUQlreI9T+QoYAFwktTByXZ7QTfvCbGNu4yamG1pD+5CXq6XH/P1QqsrztftwQtl1Kid6GkKBhszu7ZPXaSmKY0vHZBimmKwqzkpycWHsz87xEMf7ygaCJgqga02mwOWsh5/nzSE=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
            rsa.FromXmlString(HDLpublicKey);
            var dataToEncrypt = HDLencoder.GetBytes(plainText);
            var encryptedByteArray = rsa.Encrypt(dataToEncrypt, false).ToArray();
            var length = encryptedByteArray.Length;
            var item = 0;
            var sb = new StringBuilder();
            int count = 0;
            // We stick a '#' on each end of the ciphertext to make it easy to detect in the output file (see the end of this file)
            sb.Append('#');
            foreach (var x in encryptedByteArray)
            {
                item++;
                sb.Append(x);
                count++;
                if (item < length)
                {
                    sb.Append(',');
                    if (count == 15)
                    {
                        // Wrap the ciphertext if the line gets too long
                        // These line ends will get parsed out when we read the hdl file line by line.
                        // See the end of this file for the decrypt program for details.
                        sb.Append("\r\n");
                        count = 0;
                    }
                }
            }
            sb.Append('#');
            cipherText = sb.ToString();
            rsa.Dispose();
            return cipherText;
        }

        // The commented-out text below is not part of LogicCircuit.
        // It represents the "Program.cs" of a decryption program suitable for extracting the 
        // encrypted string created by HDLConvertDS() (see above). To use this program you will need to
        // generate and save a public/private key pair as described in HDLConvertDS(),
        // and then paste the public key into HDLConvertDS(), and the private key as
        // indicated below. Both keys are XML strings.
        /*
        using System;
        using System.Text;
        using System.Security.Cryptography;
        using System.IO;

        namespace DeCrypt
        {
            class Program
            {
                private static string _privateKey;
                private static UnicodeEncoding _encoder = new UnicodeEncoding();
                private static string cipherText = "";

                static void Main(string[] args)
                {
                    Console.WriteLine("Enter input file:"); // Prompt
                    string HDLFileName = Console.ReadLine();
                    if (File.Exists(HDLFileName))
                    {
                        cipherText = getCheckSum(HDLFileName);
                        string plainText = Decrypt(cipherText);
                        Console.WriteLine("Result:");
                        Console.WriteLine(plainText);
                        Console.WriteLine("Press return to exit.");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("{0} is not a valid filename.", HDLFileName);
                        Console.WriteLine("Press return to exit\n");
                        Console.ReadLine();
                        Environment.Exit(-1);
                    }
                }

                public static string Decrypt(string data)
                {
                    var rsa = new RSACryptoServiceProvider();
                    var dataArray = data.Split(new char[] { ',' });
                    byte[] dataByte = new byte[dataArray.Length];
                    for (int i = 0; i < dataArray.Length; i++)
                    {
                        dataByte[i] = Convert.ToByte(dataArray[i]);
                    }
                    _privateKey = "_YOUR_PRIVATE_RSA_KEY_";
                    rsa.FromXmlString(_privateKey);
                    var decryptedByte = rsa.Decrypt(dataByte, false);
                    return _encoder.GetString(decryptedByte);
                }

                public static string getCheckSum(string file)
                {
                    StreamReader HDLFile = new StreamReader(file);
                    bool inKey = false; // true if we are processing a potentially multi-line ciphertext (called a "key" here)
                    string line = "";
                    var sb = new StringBuilder();
                    int poundIdx = -1;

                    while (true)
                    {
                        line = HDLFile.ReadLine();
                        if (line == null)
                        {
                            Console.WriteLine("EOF");
                            HDLFile.Close();
                        }
                        else // process the line
                        {
                            poundIdx = line.IndexOf('#');
                            if (!inKey)
                            {
                                if (poundIdx < 0)
                                {
                                    continue; // nothing of interest in this line
                                }
                                else
                                {
                                    sb.Append(line.Substring(poundIdx + 1));
                                    inKey = true;
                                    continue;
                                }
                            }
                            else // we are in the middle of a key
                            {

                                if (poundIdx < 0)
                                {
                                    // grab the whole line
                                    sb.Append(line);
                                    continue; // done with this line
                                }
                                else // end of key; the the part of line
                                {
                                    sb.Append(line.Substring(0, poundIdx));
                                    Console.WriteLine("Done");
                                    HDLFile.Close();
                                    return sb.ToString();
                                }
                            }
                        }
                    }
                    // we shouldn't get here
                    return " Program Error";
                } 
            }
        }
        */


    }
}