﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 * 
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
// using Microsoft.Win32; // We use this library, but only explicitly to avoid ambiguity with System.Windows.Forms
using System.Windows.Forms;


namespace LogicCircuit
{
    public partial class CircuitProject
    {
        // In general, designers will add clocks when appropriate. N2T, however, assumes clocks on certain parts.
        // This list enumerates N2T parts with implicit clocks.
        private static readonly List<string> HDL_N2T_Parts_With_Implicit_Clock = new List<string>()
        {
            {"dff"}, {"bit"}, {"register"}, {"ram8"}, {"ram64"}, {"ram512"}, {"ram4k"}, {"ram16k"}, {"pc"},
            {"aregister"}, {"dregister"}, {"cpu"}, {"computer"},
            // this one is not an N2T part, but is included here since we map N2T "dff" to Xilinx "fd"
            {"fd"},
            // we need this since we map "PC" to "PC_Register" in VHDL to avoid a naming conflict with the CPU pin name.
            {"pc_register"}
        };

        // This dictionary makes the parts or pins we spec match the N2T builtin names
        // (so the N2T tools will accept them)
        // I also added a few of my own, based on my implementation of the Hack Computer...
        private static readonly Dictionary<string, string> HDLN2TNames = new Dictionary<string, string>()
        {
            //Parts
            {"Dmux", "DMux"}, {"Or8way", "Or8Way"}, {"Mux4way16", "Mux4Way16"}, {"Mux8way16", "Mux8Way16"}, {"Dmux4way", "DMux4Way"},
            {"Dmux8way", "DMux8Way"}, {"Halfadder", "HalfAdder"}, {"Fulladder", "FullAdder"}, {"Alu", "ALU"}, {"Dff", "DFF"},
            {"Ram8", "RAM8"}, {"Ram64", "RAM64"}, {"Ram512", "RAM512"}, {"Ram4k", "RAM4K"}, {"Ram16k", "RAM16K"}, {"Pc", "PC"},
            {"Cpu", "CPU"}, {"Rom32k", "ROM32K"}, {"Aregister", "ARegister"}, {"Dregister", "DRegister"},
            // CPU Pins
            {"inm", "inM"}, {"addressm", "addressM"}, {"writem", "writeM"}, {"outm", "outM"},
            // JKB Names - these are used in my implementation of the N2T Computer
            {"Insdecode", "InsDecode"}, {"Jumplogic", "JumpLogic"}
        };

        
        // One of three entry points from the LC user interface: "Save as HDL..."
        public void WriteHDLFile()
        {
            // We have the option of just saving the current circuit,
            // or saving all circuits in the project.
            DialogResult dialogResult = MessageBox.Show("Save all circuits in this project as HDL?", "Inclusive Save?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                WriteHDLFileInclusive();
            }
            else if (dialogResult == DialogResult.No)
            {
                WriteHDLFileNR(this.ProjectSet.Project.LogicalCircuit, ""); // empty string as the directory name means single circuit save
            }
        }

        // Save all circuits in this project as HDL
        private void WriteHDLFileInclusive()
        {
            string hdlSavePath = "";
            FolderBrowserDialog fbd = new FolderBrowserDialog
            {
                Description = "Choose (or create) folder where all HDL files will be saved",
                RootFolder = Environment.SpecialFolder.Desktop // default to desktop
            };
            DialogResult dirResult = fbd.ShowDialog();
            if (dirResult == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
            {
                if (fbd.SelectedPath == Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) // user did not specify a directory, so specify one for them (in the current directory)
                {
                    hdlSavePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\HDL_SAVE_DIR";
                }
                else // the user completed the dialog selection, so use what they entered
                {
                    hdlSavePath = fbd.SelectedPath;
                }
            }
            else // if all else fails, just specify a directory
            {
                hdlSavePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\HDL_SAVE_DIR";
            }

            // Is this a legal directory path name? If not, fix it
            hdlSavePath = CheckName(hdlSavePath, "-"); // Use dash, since HDL chokes on underscore: '_'

            // make the directory if needed
            if (!Directory.Exists(hdlSavePath)) // if the directory does not exist, create it
            {
                Directory.CreateDirectory(hdlSavePath);
            }
            foreach (LogicalCircuit logicalCkt in this.LogicalCircuitSet)
            {
                WriteHDLFileNR(logicalCkt, hdlSavePath);
            }
            fbd.Dispose();
        }

        // Save single circuit as HDL
        private void WriteHDLFileNR(LogicalCircuit logCkt, string dirName)
        {
            HDLinPinList = new List<HDLpin>();
            HDLoutPinList = new List<HDLpin>();
            HDLProjectPinDirection = new Dictionary<string, string>();
            HDLpartList = new List<HDLpart>();
            HDLwireList = new Dictionary<GridPoint, string>();
            HDLPARTStatements = new List<string>();
            HDLnameInt = -1;        // used to build unique wire names when needed
            HDLnumOpenPins = 0;     // unused output pins
            HDLnumUnusedPins = 0;   // unused input pins
            HDLnumRegularParts = 0;
            HDLnumSplitterParts = 0;
            HDLwtbNameInt = -1;
            HDLsrcInt = -1;         // This is really used; do not delete
            HDLclockDefined = false;
            string fname = "";

            try
            {
                string capProjectName = logCkt.Name;     // the working name of this circuit project during translation
                HDLOrigprojectName = capProjectName;     // the original name of this circuit project
                if (Char.IsLetter(capProjectName.First())) capProjectName = capProjectName.First().ToString().ToUpper() + capProjectName.Substring(1);
                if (HDL_Enforce_N2T_Compatibility && HDLN2TNames.ContainsKey(capProjectName)) capProjectName = HDLN2TNames[capProjectName]; // make the part name match N2T part names
                HDLprojectName = capProjectName;

                // Is this a legal file name? If not, fix it
                HDLprojectName = CheckName(HDLprojectName, "-"); // Use dash, since HDL chokes on underscore: '_'

                HDLprojCktID = logCkt.LogicalCircuitId;
                if (dirName.Length == 0) // not inclusive save
                {
                    Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog
                    {
                        Title = "Save project as Nand2Tetris .hdl file",
                        DefaultExt = ".hdl",
                        FileName = HDLprojectName,
                        Filter = "HDL files (*.hdl)|*.hdl|All files (*.*)|*.*",
                        FilterIndex = 1,
                        RestoreDirectory = true,
                        InitialDirectory = Mainframe.DefaultProjectFolder(),
                        CheckPathExists = true
                    };
                    bool? result = dialog.ShowDialog();
                    if (result.HasValue && result.Value)
                    {
                        // Make sure name is OK
                        fname = CheckName(dialog.FileName, "-"); // Use dash, since HDL chokes on underscore: '_'                      

                        try
                        {
                            HDLOutFile = new StreamWriter(fname);
                        }
                        catch
                        {
                            // We shouldn't execute this code, since we fixed the file/path name
                            // This filename is invalid
                            throw new CircuitException(Cause.UserError,
                                   string.Format(CultureInfo.InvariantCulture,
                                   "Circuit Names must be valid Windows filename prefixes." + "\n" +
                                   "Rename Circuit {0} to be a valid filename prefix.", dialog.FileName));
                        }
                    }
                    else
                    {
                        throw new CircuitException(Cause.UserError,
                           string.Format(CultureInfo.InvariantCulture, "Unable to create file."));
                    }
                }
                else // inclusive save
                {
                    try
                    {
                        // Make sure name is OK
                        fname = CheckName(logCkt.Name, "-"); // Use dash, since HDL chokes on underscore: '_'  
                        HDLOutFile = new StreamWriter(dirName + "\\" + fname + ".hdl");
                    }
                    catch
                    {
                        // We shouldn't execute this code, since we fixed the file name
                        // This filename is invalid
                        throw new CircuitException(Cause.UserError,
                               string.Format(CultureInfo.InvariantCulture,
                               "Circuit Names must be valid Windows filename prefixes." + "\n" +
                               "Rename Circuit {0} to be a valid filename prefix.", logCkt.Name));
                    }
                }

                // Write HDL Header
                HDLOutFile.WriteLine("// This file was generated from LogicCircuit CircuitProject: {0}", HDLOrigprojectName);
                if (HDLOrigprojectName != HDLprojectName)
                {
                    HDLOutFile.WriteLine("// During translation, CircuitProject name '{0}' was converted to '{1}'.", HDLOrigprojectName, HDLprojectName);
                    HDLOutFile.WriteLine("// You may wish to make this change in LogicCircuit to ensure future compatibility.");
                }
                HDLOutFile.WriteLine("// Please report issues to jkb@colorado.edu");
                DateTime datetime = DateTime.Now;
                if (HDLwriteCheckSum) // If used in a Nand2Tetris course, write a unique checksum to prove authorship
                {
                    // OK that this is unreachable code; it won't be if we turn on the checksum code
                    string user = Environment.UserName;
                    string machine = Environment.MachineName;
                    string projName = HDLprojectName;
                    if ((user.Length + machine.Length + projName.Length) > 30)
                    {
                        if (user.Length >= 6) user = user.Substring(0, 6);
                        if (machine.Length >= 6) machine = machine.Substring(0, 6);
                        if (projName.Length >= 16) projName = projName.Substring(0, 16);
                    }

                    string datestamp = datetime.ToString() + " " + user + " " + machine + " " + projName;
                    string cVal = HDLConvertDS(datestamp);
                    HDLOutFile.WriteLine("// {0}", datetime.ToString());
                    HDLOutFile.WriteLine("/* " + cVal);
                    HDLOutFile.WriteLine("*/");
                }
                else
                {
                    // OK that this is unreachable code; it won't be if we turn off the checksum code
                    HDLOutFile.WriteLine("// {0}", datetime.ToString());
                }
                HDLOutFile.WriteLine();
                HDLOutFile.WriteLine("CHIP {0} {{", HDLprojectName);

                if (HDLAnalyzeCircuit(/*VHDL*/ false, /*VERILOG*/ false, logCkt, dirName))
                    // Output to HDL file
                    HDLCreateFile();
            }
            catch (Exception exception)
            {
                App.Mainframe.ReportException(exception);
            }
        }

        private void HDLCreateFile()
        {
            HDLWriteInsAndOuts();
            HDLWriteParts();
            // Write HDL Footer
            HDLOutFile.WriteLine("}");
            HDLOutFile.Close();
        }

        private void HDLWriteInsAndOuts()
        {
            // Write Inputs
            //In rare cases (e.g., the N2T KeyBoard) there will be no inputs; test for this and omit inputs if not present
            if (HDLinPinList.Count != 0)
            {
                HDLOutFile.Write("IN ");
                // Find all of the input pins
                // These are indentified by having an assigned input pin on the schematic
                // HDL uses implied clocks (it knows which parts are clocked), so we don't write these to the HDL file
                bool sawOne = false;
                for (int i = 0; i < HDLinPinList.Count - 1; i++)
                {
                    if (sawOne) HDLOutFile.Write(", ");
                    sawOne = false;
                    if (HDLinPinList[i].pinWidth == 1)
                    {
                        if (HDLinPinList[i].pinName != "c*l*k") HDLOutFile.Write(HDLinPinList[i].pinName);
                        sawOne = true;
                    }
                    else
                    {
                        HDLOutFile.Write(HDLinPinList[i].pinName + "[" + HDLinPinList[i].pinWidth + "]");
                        sawOne = true;
                    }
                }
                if (sawOne) HDLOutFile.Write(", ");
                if (HDLinPinList[HDLinPinList.Count - 1].pinWidth == 1)
                {
                    if (HDLinPinList[HDLinPinList.Count - 1].pinName != "c*l*k")
                        HDLOutFile.WriteLine(HDLinPinList[HDLinPinList.Count - 1].pinName + ";");
                    else HDLOutFile.WriteLine(";");
                }
                else
                {
                    HDLOutFile.WriteLine(HDLinPinList[HDLinPinList.Count - 1].pinName
                        + "[" + HDLinPinList[HDLinPinList.Count - 1].pinWidth + "]" + ";");
                }
            }

            // HDLOutFile.WriteLine(); uncomment to add a line between the IN and OUT declarations

            // Write Outputs
            //In rare cases (e.g., the N2T CPU) there will be no outputs; test for this and omit outputs if not present
            if (HDLoutPinList.Count != 0)
            {
                HDLOutFile.Write("OUT ", HDLprojectName);
                // Find all of the output pins
                // These are indentified by having an assigned output pin on the schematic
                for (int i = 0; i < HDLoutPinList.Count - 1; i++)
                {
                    if (HDLoutPinList[i].pinWidth == 1)
                    {
                        HDLOutFile.Write(HDLoutPinList[i].pinName + ", ");
                    }
                    else
                    {
                        HDLOutFile.Write(HDLoutPinList[i].pinName + "[" + HDLoutPinList[i].pinWidth + "]" + ", ");
                    }
                }
                if (HDLoutPinList[HDLoutPinList.Count - 1].pinWidth == 1)
                {
                    HDLOutFile.WriteLine(HDLoutPinList[HDLoutPinList.Count - 1].pinName + ";");
                }
                else
                {
                    HDLOutFile.WriteLine(HDLoutPinList[HDLoutPinList.Count - 1].pinName
                        + "[" + HDLoutPinList[HDLoutPinList.Count - 1].pinWidth + "]" + ";");
                }
                HDLOutFile.WriteLine();
            }
        }

        private void HDLWriteParts()
        {
            // Write Parts Header
            HDLOutFile.WriteLine("PARTS:");
            // Write All Parts
            for (int j = 0; j < HDLpartList.Count; j++)
            //if (HDLpartList[j].partType == HDLPartType.RegularPart)
            {
                string pName = HDLpartList[j].partName;

                if (HDLpartList[j].partType == HDLPartType.RegularPart)
                {
                    string capPartName = pName;
                    if (Char.IsLetter(pName.First())) capPartName = pName.First().ToString().ToUpper() + pName.Substring(1);
                    if (HDL_Enforce_N2T_Compatibility && HDLN2TNames.ContainsKey(capPartName)) capPartName = HDLN2TNames[capPartName]; // make the part name match N2T part names

                    // Change the partname if needed
                    capPartName = CheckName(capPartName, "-", false); // Use dash, since HDL chokes on underscore: '_'

                    HDLOutFile.Write(capPartName);
                    // If the primWidth is not null or 1, append it to the gate part; ignore any buffers
                    if ((HDLpartList[j].primWidth.Length != 0) &&
                            ((HDLpartList[j].primWidth != "1") && // "Not1" actually works (with my version of builtInChips), but looks stupid
                                ((HDLpartList[j].partName.Length < 4) ||
                                    ((HDLpartList[j].partName.Length >= 4) &&
                                        (HDLpartList[j].partName.Substring(0, 4) != "Buff")))))
                        HDLOutFile.Write(HDLpartList[j].primWidth);
                    HDLOutFile.Write(" (");

                    // Write the connection list
                    int last = HDLpartList[j].partPinList.Count - 1;
                    bool sawOne = false;
                    int termCount = 0;
                    for (int i = 0; i < last; i++)
                    {
                        if (HDLwireList.ContainsKey(HDLpartList[j].partPinList[i].pinAbsLoc))
                        {
                            string wireName = HDLwireList[HDLpartList[j].partPinList[i].pinAbsLoc];
                            // We keep track of open pins internally, but HDL does not want to hear about them. Ever.
                            string RightSide = HDLProcessWireName(wireName, false, false);
                            if (RightSide[0] == '*') RightSide = RightSide.Replace("*", "U");  // clean up our working wire name
                            if ((RightSide != "open") && (RightSide != "c*l*k"))
                            {
                                if (sawOne) HDLOutFile.Write(", ");
                                if (termCount >= 5)
                                {
                                    HDLOutFile.WriteLine();
                                    HDLOutFile.Write("        ");
                                    termCount = 0;
                                }
                                HDLOutFile.Write(HDLpartList[j].partPinList[i].pinName + " = " +
                                    RightSide);
                                termCount++;
                                sawOne = true;
                            }
                        }
                        else throw new CircuitException(Cause.UserError,
                                string.Format(CultureInfo.InvariantCulture,
                                "HDLwireList did not have an entry for {0} on Part {1} at {2}",
                                HDLpartList[j].partPinList[i].pinAbsLoc, HDLpartList[j].partName, HDLpartList[j].partLoc));
                    }

                    // Insert any extra terms here. These are the ones where we have multiple named pins tied to an output
                    int pNum = HDLpartList[j].partNum;
                    if ((pNum >= 0) && (pNum < HDLoutPinAdds.Length))
                    {
                        foreach (string term in HDLoutPinAdds[pNum])
                        {
                            if (sawOne) HDLOutFile.Write(", ");
                            if (termCount >= 5)
                            {
                                HDLOutFile.WriteLine();
                                HDLOutFile.Write("        ");
                                termCount = 0;
                            }
                            HDLOutFile.Write(term);
                            termCount++;
                        }
                    }

                    //Now the last one
                    if (HDLwireList.ContainsKey(HDLpartList[j].partPinList[last].pinAbsLoc))
                    {
                        string RightSide = HDLProcessWireName(HDLwireList[HDLpartList[j].partPinList[last].pinAbsLoc], false, false);
                        if (RightSide[0] == '*') RightSide = RightSide.Replace("*", "U");
                        if (RightSide != "open")
                        {
                            if (sawOne) HDLOutFile.Write(", ");
                            if (termCount >= 5)
                            {
                                HDLOutFile.WriteLine();
                                HDLOutFile.Write("        ");
                                termCount = 0;
                            }
                            HDLOutFile.WriteLine(HDLpartList[j].partPinList[last].pinName + " = " +
                            RightSide + "); ");
                        }
                        else HDLOutFile.WriteLine("); ");
                    }
                    else throw new CircuitException(Cause.UserError,
                           string.Format(CultureInfo.InvariantCulture,
                           "HDLwireList did not have an entry for {0} on Part {1} at {2}",
                            HDLpartList[j].partPinList[last].pinAbsLoc, HDLpartList[j].partName, HDLpartList[j].partLoc));
                }
            }
            // Output any "Buff" statements that we had to create
            foreach (string buffStatement in HDLPARTStatements) HDLOutFile.WriteLine(buffStatement);
        }


    }
}