﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 * 
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
// using Microsoft.Win32; // We use this library, but only explicitly to avoid ambiguity with System.Windows.Forms
using System.Windows.Forms;

namespace LogicCircuit
{
    public partial class CircuitProject
    {
        // This dictionary maps LogicCircuit pimitive names to Xilinx primitive macro names
        private static readonly Dictionary<string, string> HDLXilinxNames = new Dictionary<string, string>()
        {
            {"nand", "NAND"}, {"or", "OR"}, {"and", "AND"}, {"nor", "NOR"}, {"xor", "XOR"},
            {"xnor", "XNOR"}, {"not", "INV"}, {"dff", "FD"}, {"mux", "MUXF7"}
        };

        private static string XilinxMapPinName(string pinName, string partName)
        {
            // Map the part pin names we find in LogicCircuit to the corresponding Xilinx primitive part pin name
            if (partName == "FD")
                switch (pinName)
                {
                    case "in":
                        return "D";
                    case "out":
                        return "Q";
                    case "clk":
                        return "C";
                    default:
                        return "bad_FD_pin_name";
                }

            else switch (pinName)
                {
                    case "x1":
                    case "a":
                        return "I0";
                    case "x2":
                    case "b":
                        return "I1";
                    case "x3":
                    case "c":
                        return "I2";
                    case "x4":
                    case "d":
                        return "I3";
                    case "x5":
                    case "e":
                        return "I4";
                    case "x6":
                    case "f":
                        return "I5";
                    case "x7":
                    case "g":
                        return "I6";
                    case "x8":
                    case "h":
                        return "I7";
                    case "in":
                    case "x":
                        return "I";
                    case "sel":
                        return "S";
                    case "out":
                    case "q":
                        return "O";
                    default:
                        return "bad_pin_name";
                }
        }

    }
}