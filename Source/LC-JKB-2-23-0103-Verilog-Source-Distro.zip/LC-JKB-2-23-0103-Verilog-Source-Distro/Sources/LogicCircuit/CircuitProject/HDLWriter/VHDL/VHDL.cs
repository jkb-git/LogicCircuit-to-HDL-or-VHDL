﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 *  
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
// using Microsoft.Win32; // We use this library, but only explicitly to avoid ambiguity with System.Windows.Forms
using System.Windows.Forms;

namespace LogicCircuit
{
    public partial class CircuitProject
    {
        // This list helps us avoid producing a VHDL reserved word as a name
        private static readonly List<string> HDL_VHDLReservedWords = new List<string>()
        {
            {"abs"}, {"access"}, {"after"}, {"alias"}, {"all"}, {"and"}, {"architecture"}, {"array"}, {"assert"}, {"attribute"},
            { "begin"}, {"block"}, {"body"}, {"buffer"}, {"bus"}, {"case"}, {"component"}, {"configuration"}, {"constant"},
            { "disconnect"}, {"downto"}, {"else"}, {"elsif"}, {"end"}, {"entity"}, {"exit"}, {"file"}, {"for"}, {"function"}, {"generate"},
            { "generic"}, {"guarded"}, {"if"}, {"impure "}, {"in"}, {"inertial"}, {"inout"}, {"is"}, {"label"}, {"library"}, {"linkage"},
            { "literal"}, {"loop"}, {"map"}, {"mod"}, {"nand"}, {"new"}, {"next"}, {"nor"}, {"not"}, {"null"}, {"of"}, {"on"}, {"open"},
            { "or"}, {"others"}, {"out"}, {"package"}, {"port"}, {"postponed"}, {"procedure"}, {"process"}, {"pure"}, {"range"}, {"record"},
            { "register"}, {"reject"}, {"rem"}, {"report"}, {"return"}, {"rol"}, {"ror"}, {"select"}, {"severity"}, {"shared"}, {"signal"},
            { "sla "}, {"sll"}, {"sra"}, {"srl"}, {"subtype"}, {"then"}, {"to"}, {"transport"}, {"type"}, {"unaffected"}, {"units"}, {"until"},
            { "use"}, {"variable"}, {"wait"}, {"when"}, {"while"}, {"with"}, {"xnor"}, {"xor"},
            // Not actual VHDL reserved words, but included here to avoid potential naming conflict with Xilinx macros
            {"mux"}, {"add"}
        };

        // One of three entry points from the LC user interface: "Save as VHDL..."
        public void WriteVHDLFile()
        {
            // For VHDL, we have the option of just saving the current circuit,
            // or saving all circuits in the project.
            DialogResult dialogResult = MessageBox.Show("Save all circuits in this project as VHDL?", "Inclusive Save?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                WriteVHDLFileInclusive();
            }
            else if (dialogResult == DialogResult.No)
            {
                WriteVHDLFileNR(this.ProjectSet.Project.LogicalCircuit, ""); // empty string as the directory name means single circuit save
            }
        }

        // Save all circuits in this project as VHDL
        private void WriteVHDLFileInclusive()
        {
            string hdlSavePath = "";
            FolderBrowserDialog fbd = new FolderBrowserDialog
            {
                Description = "Choose (or create) folder where all VHDL files will be saved",
                RootFolder = Environment.SpecialFolder.Desktop // default
            };
            DialogResult dirResult = fbd.ShowDialog();
            if (dirResult == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
            {
                if (fbd.SelectedPath == Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) // user did not specify a directory, so specify one for them (in the current directory)
                {
                    hdlSavePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\VHDL_SAVE_DIR";
                }
                else // the user completed the dialog selection, so use what they entered
                {
                    // Is this a legal directory path name? If not, fix it
                    hdlSavePath = CheckName(fbd.SelectedPath, "_"); // Use underscore for VHDL (which chokes on dash) 
                }
            }
            else // if all else fails, just specify a directory
            {
                hdlSavePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\VHDL_SAVE_DIR";
            }
            if (!Directory.Exists(hdlSavePath)) // if the directory does not exist, create it
            {
                Directory.CreateDirectory(hdlSavePath);
            }
            foreach (LogicalCircuit logicalCkt in this.LogicalCircuitSet)
            {
                WriteVHDLFileNR(logicalCkt, hdlSavePath);
            }
            fbd.Dispose();
        }

        // Save single circuit as VHDL
        private void WriteVHDLFileNR(LogicalCircuit logCkt, string dirName)
        {
            HDLinPinList = new List<HDLpin>();
            HDLoutPinList = new List<HDLpin>();
            HDLProjectPinDirection = new Dictionary<string, string>();
            HDLpartList = new List<HDLpart>();
            HDLwireList = new Dictionary<GridPoint, string>();
            HDLsignalsList = new Dictionary<string, int>();
            HDLconcurrentStatements = new List<string>();
            HDLnameInt = -1;    // used to build unique wire names when needed
            HDLnumOpenPins = 0; // unused output pins
            HDLnumUnusedPins = 0;   // unused input pins
            HDLnumRegularParts = 0;
            HDLnumSplitterParts = 0;
            HDLwtbNameInt = -1;
            HDLsrcInt = -1;
            HDLclockDefined = false;
            string fname = "";

            try
            {
                HDLprojectName = logCkt.Name;            // the working name of this circuit project during translation
                HDLOrigprojectName = HDLprojectName;     // the original name of this circuit project               
                if (HDLprojectName.ToLower() == "pc") HDLprojectName = "PC_Register";
                HDLprojCktID = logCkt.LogicalCircuitId;

                // Is this a legal file name? If not, fix it
                HDLprojectName = CheckName(HDLprojectName, "_"); // Use underscore, since VHDL chokes on dash: '-'

                if (dirName.Length == 0) // not inclusive save
                {
                    Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog
                    {
                        Title = "Save this circuit as Structural VHDL .vhd file",
                        DefaultExt = ".vhd",
                        FileName = HDLprojectName,
                        Filter = "VHDL files (*.vhd)|*.vhd|All files (*.*)|*.*",
                        FilterIndex = 1,
                        RestoreDirectory = true,
                        InitialDirectory = Mainframe.DefaultProjectFolder(),
                        CheckPathExists = true
                    };
                    bool? result = dialog.ShowDialog();
                    if (result.HasValue && result.Value)
                    {
                        try
                        {
                            // Is this a legal file name? If not, fix it
                            fname = CheckName(dialog.FileName, "_"); // Use underscore for VHDL (which chokes on dash) 
                            HDLOutFile = new StreamWriter(fname);
                        }
                        catch
                        {
                            // The filename is invalid; this code should not be executed since we fixed the name
                            throw new CircuitException(Cause.UserError,
                                   string.Format(CultureInfo.InvariantCulture,
                                   "Circuit Names must be valid Windows filename prefixes." + "\n" +
                                   "Rename Circuit {0} to be a valid filename prefix.", dialog.FileName));
                        }
                    }
                    else
                    {
                        throw new CircuitException(Cause.UserError,
                           string.Format(CultureInfo.InvariantCulture, "Unable to create file."));
                    }
                }
                else // inclusive save
                {
                    try
                    {
                        // Is this a legal file name? If not, fix it
                        fname = CheckName(logCkt.Name, "_"); // Use underscore for VHDL (which chokes on dash) 
                        HDLOutFile = new StreamWriter(dirName + "\\" + fname + ".vhd");
                    }
                    catch
                    {
                        // We shouldn't see this exception since we fixed the name
                        // The filename is invalid
                        throw new CircuitException(Cause.UserError,
                               string.Format(CultureInfo.InvariantCulture,
                               "Circuit Names must be valid Windows filename prefixes." + "\n" +
                               "Rename Circuit {0} to be a valid filename prefix.", logCkt.Name));
                    }
                }
                // Write VHDL Header
                HDLOutFile.WriteLine("-- This file was generated from LogicCircuit CircuitProject: {0}", HDLOrigprojectName);
                if (HDLOrigprojectName != HDLprojectName)
                {
                    HDLOutFile.WriteLine("-- During translation, CircuitProject name '{0}' was converted to '{1}'.", HDLOrigprojectName, HDLprojectName);
                    HDLOutFile.WriteLine("-- You may wish to make this change in LogicCircuit to ensure future compatibility.");
                }
                HDLOutFile.WriteLine("-- Please report issues to jkb@colorado.edu");
                HDLOutFile.WriteLine("-- {0}", DateTime.Now.ToString());
                HDLOutFile.WriteLine();
                HDLOutFile.WriteLine("library IEEE;");
                HDLOutFile.WriteLine("use IEEE.std_logic_1164.all;");
                HDLOutFile.WriteLine();
                HDLOutFile.WriteLine("entity {0} is", VHDLReplaceReservedWord(HDLprojectName));
                HDLOutFile.WriteLine("port (");

                if (HDLAnalyzeCircuit(/*VHDL*/ true, /*VERILOG*/ false, logCkt, dirName))
                    // Output to VHDL file
                    VHDLCreateFile();
            }
            catch (Exception exception)
            {
                App.Mainframe.ReportException(exception);
            }
        }

        private void VHDLCreateFile()
        {
            VHDLwritePorts();
            VHDLwriteComponents();
            VHDLwriteSignals();
            VHDLwritePortMaps();
            VHDLwriteConcurrentStatements();
            // Write VHDL Footer
            HDLOutFile.WriteLine("end structural;");
            HDLOutFile.Close();
        }

        private void VHDLwritePorts()
        {
            // Find all of the input pins
            // These are indentified by having an assigned input pin on the schematic
            // VHDL does not uses implied clocks, so these must be declared in the VHDL file

            // declare all of the named pins of this chip -- yes this is inefficient
            // do the one-bit IN's first
            for (int i = 0; i < HDLinPinList.Count; i++)
            {
                if (HDLinPinList[i].pinWidth == 1)
                    if (HDLinPinList[i].pinName != "clk") HDLOutFile.WriteLine(VHDLReplaceReservedWord(HDLinPinList[i].pinName)
                        + " : in std_logic;");
            }
            // add the clock input if needed
            for (int i = 0; i < HDLinPinList.Count; i++)
            {
                if (HDLinPinList[i].pinWidth == 1)
                    if (HDLinPinList[i].pinName == "clk") HDLOutFile.WriteLine("clk : in std_logic;");
            }

            // now do the multibit IN's
            for (int i = 0; i < HDLinPinList.Count; i++)
            {
                if (HDLinPinList[i].pinWidth > 1)
                    HDLOutFile.WriteLine(VHDLReplaceReservedWord(HDLinPinList[i].pinName)
                        + " : in std_logic_vector ({0} downto 0);", (HDLinPinList[i].pinWidth - 1));
            }

            // Find all of the output pins
            // These are indentified by having an assigned output pin on the schematic
            // Originally, I made all outputs VHDL "buffers" to make it easy to use them as inputs; the
            // Xilinx VHDL compiler whined about this, but only a little. Changed to "out" in the most recent
            // version because the code is now smarter about signals.
            int numPinsWritten = 0;
            // do the one-bit OUT's
            for (int i = 0; i < HDLoutPinList.Count; i++)
            {
                if (HDLoutPinList[i].pinWidth == 1)
                {
                    HDLOutFile.Write(VHDLReplaceReservedWord(HDLoutPinList[i].pinName) + " : out std_logic"); // "out was "buffer"
                    numPinsWritten++;
                    if (numPinsWritten < HDLoutPinList.Count) HDLOutFile.WriteLine(";");
                    else HDLOutFile.WriteLine(");");
                }
            }

            // now do the multibit OUT's
            for (int i = 0; i < HDLoutPinList.Count; i++)
            {
                if (HDLoutPinList[i].pinWidth > 1)
                {
                    HDLOutFile.Write(VHDLReplaceReservedWord(HDLoutPinList[i].pinName)
                        + " : out std_logic_vector ({0} downto 0)", (HDLoutPinList[i].pinWidth - 1)); // "out was "buffer"
                    numPinsWritten++;
                    if (numPinsWritten < HDLoutPinList.Count) HDLOutFile.WriteLine(";");
                    else HDLOutFile.WriteLine(");");
                }
            }
            HDLOutFile.WriteLine("end entity {0};", VHDLReplaceReservedWord(HDLprojectName));
            HDLOutFile.WriteLine();
        }

        private void VHDLwriteComponents()
        {
            HDLOutFile.WriteLine("architecture structural of {0} is", VHDLReplaceReservedWord(HDLprojectName));
            List<string> UsedComponents = new List<string>();
            for (int j = 0; j < HDLpartList.Count; j++)
            {
                if (HDLpartList[j].partType == HDLPartType.RegularPart)
                {
                    string pName = HDLpartList[j].partName;
                    if (pName.Length >= 3)
                    {
                        if (pName.Substring(0, 3) == "BTN") pName = "BTN";
                    }
                    string capPartName = pName;
                    if (Char.IsLetter(pName.First())) capPartName = pName.First().ToString().ToUpper() + pName.Substring(1);
                    if (HDL_Enforce_N2T_Compatibility && HDLN2TNames.ContainsKey(capPartName)) capPartName = HDLN2TNames[capPartName]; // make the part name match N2T part names
                    if (capPartName == "PC") capPartName = "PC_Register";
                    string capPartNameLC = capPartName.ToLower();

                    // Change the partname if needed
                    capPartName = CheckName(capPartName, "_", false); // Use underscore, since HDL chokes on dash: '-'

                    // We only list a component once, so keep a list of the ones we have seen
                    if (UsedComponents.Contains(capPartNameLC)) continue;

                    // If this is a primitive part (And, Or, Not, Nand, Nor, Xor, XNor, Mux or DFF), and the part width  is <= 5,
                    // use the Xilinx primitive name, and, if appropriate, append the primitive width to invoke the correct Xilinx primitive.
                    // We have already done the append when we defined the part.

                    bool ok = Int32.TryParse(HDLpartList[j].primWidth, out int primFanIn);
                    if (HDLXilinxNames.ContainsKey(capPartNameLC))
                    {
                        if ((primFanIn > 0) && (primFanIn <= 5)) HDLOutFile.Write("component " + pName);
                        else if ((primFanIn > 5) && (primFanIn <= 8))
                            HDLOutFile.Write("component " + VHDLReplaceReservedWord(capPartName) + HDLpartList[j].primWidth);
                        else if (primFanIn > 8)
                        {
                            HDLOutFile.Write("-- ***********\n");
                            HDLOutFile.Write("-- LogicCircuit Component {0} with fan-in of {1} will fail to compile as a Xilinx prim.\n", HDLpartList[j].partName, HDLpartList[j].primWidth);
                            HDLOutFile.Write("-- Xilinx prim fan-in must be <= 8.\n");
                            HDLOutFile.Write("-- Replace LogicCircuit component {0} with a lower-level implementation of {0}{1}.\n", HDLpartList[j].partName, HDLpartList[j].primWidth);
                            HDLOutFile.Write("-- ***********\n");
                            HDLOutFile.Write("component " + VHDLReplaceReservedWord(capPartName) + HDLpartList[j].primWidth + "\n");
                            HDLOutFile.Write("-- ***********\n");

                            // we are producing a part that will not compile, so tell the user
                            string message = string.Format(CultureInfo.InvariantCulture,
                                   "Xilinx Prim {0} fan-in of {1} is too large (must be <= 8).\n This component will fail to compile with Xilinx tools." + "\n", HDLpartList[j].partName, HDLpartList[j].primWidth);
                            string title = "Warning";
                            MessageBox.Show(message, title);
                        }
                        else HDLOutFile.Write("component " + VHDLReplaceReservedWord(capPartName));
                    }
                    else
                    {
                        HDLOutFile.Write("component " + VHDLReplaceReservedWord(capPartName));
                    }
                    UsedComponents.Add(capPartNameLC);
                    HDLOutFile.WriteLine();
                    HDLOutFile.WriteLine("port (");
                    bool partClockDefined = false;

                    foreach (HDLpin pin in (HDLpartList[j].partPinList))
                    {
                        if (pin.pinDir == "Input")
                            if (pin.pinWidth == 1)
                            {
                                string pnm = pin.pinName;
                                // If the component maps to a Xilinx primitive (i.e., its name is an HDLXilinxNames dictionary value),
                                // we have to rename the pins to map to the pin names of the Xilinx primitive. All pin widths of the Xilinx
                                // primitives (at least the ones we are using) are single bit width.
                                string rootName = new String(HDLpartList[j].partName.TakeWhile(Char.IsLetter).ToArray());
                                if ((HDLXilinxNames.ContainsValue(rootName) || (rootName == "MUXF")) && ((primFanIn > 0) && (primFanIn <= 5))) // the root for "MUXF7"
                                { // we need to map pin names
                                    pnm = XilinxMapPinName(pnm, HDLpartList[j].partName);
                                }

                                HDLOutFile.WriteLine(VHDLReplaceReservedWord(pnm) + " : in std_logic;");
                                if ((pin.pinName.ToLower() == "clk") || (pin.pinName.ToLower() == "clock")) partClockDefined = true;
                            }
                            else HDLOutFile.WriteLine(VHDLReplaceReservedWord(pin.pinName)
                                + " : in std_logic_vector ({0} downto 0);", (pin.pinWidth - 1));
                    }

                    if (!partClockDefined)
                    {
                        if (HDL_Enforce_N2T_Compatibility && HDL_N2T_Parts_With_Implicit_Clock.Contains(capPartNameLC))
                        {
                            // We need to add a clock input to this part
                            partClockDefined = true;

                            if (HDLpartList[j].partName != "FD")
                                HDLOutFile.WriteLine("clk : in std_logic;");
                            else
                                HDLOutFile.WriteLine("C : in std_logic;");
                        }
                    }

                    bool sawOne = false;
                    foreach (HDLpin pin in (HDLpartList[j].partPinList))
                    {
                        if (sawOne)
                        {
                            HDLOutFile.WriteLine(";"); sawOne = false;
                        }
                        if (pin.pinDir == "Output")
                        {
                            string pnm = pin.pinName;
                            if (pin.pinWidth == 1)
                            {
                                // If the component maps to a Xilinx primitive (i.e., its name is an HDLXilinxNames dictionary value),
                                // we have to rename the pins to map to the pin names of the Xilinx primitive. All pin widths of the Xilinx
                                // primitives (at least the ones we are using) are single bit width.
                                string rootName = new String(HDLpartList[j].partName.TakeWhile(Char.IsLetter).ToArray());
                                if ((HDLXilinxNames.ContainsValue(rootName) || (rootName == "MUXF")) && ((primFanIn > 0) && (primFanIn <= 5))) // the root for "MUXF7"
                                { // we need to map pin names
                                    pnm = XilinxMapPinName(pnm, HDLpartList[j].partName);
                                }
                                HDLOutFile.Write(VHDLReplaceReservedWord(pnm) + " : out std_logic");
                            }
                            else HDLOutFile.Write(VHDLReplaceReservedWord(pin.pinName)
                                + " : out std_logic_vector ({0} downto 0)", (pin.pinWidth - 1));
                            sawOne = true;
                        }
                    }
                    HDLOutFile.WriteLine(");");
                    //if (button) HDLOutFile.Write("-- ");
                    HDLOutFile.WriteLine("end component;");
                    HDLOutFile.WriteLine();
                }
            }
        }

        private void VHDLwriteSignals()
        {
            if (HDLsignalsList.Count > 0)
            {
                HDLOutFile.WriteLine("-- Signals");
                foreach (KeyValuePair<string, int> kvp in HDLsignalsList)
                {
                    if (kvp.Value == 1) HDLOutFile.WriteLine("signal {0}: std_logic;", kvp.Key);
                    else HDLOutFile.WriteLine("signal {0}: std_logic_vector ({1} downto 0);", kvp.Key, kvp.Value - 1);
                }
                HDLOutFile.WriteLine();
            }
        }

        private void VHDLwritePortMaps()
        {
            HDLOutFile.WriteLine("begin");
            for (int j = 0; j < HDLpartList.Count; j++)
                // only the "regular" parts are components whose ports get mapped
                if (HDLpartList[j].partType == HDLPartType.RegularPart)
                {
                    bool ok = Int32.TryParse(HDLpartList[j].primWidth, out int primFanIn);
                    string pName = HDLpartList[j].partName;
                    string capPartName = pName;
                    if (Char.IsLetter(pName.First())) capPartName = pName.First().ToString().ToUpper() + pName.Substring(1);
                    if (HDL_Enforce_N2T_Compatibility && HDLN2TNames.ContainsKey(capPartName)) capPartName = HDLN2TNames[capPartName]; // make the part name match N2T part name
                    if (capPartName == "PC") capPartName = "PC_Register";
                    if ((primFanIn > 5) && (primFanIn <= 8))
                        capPartName = VHDLReplaceReservedWord(capPartName) + HDLpartList[j].primWidth;
                    else if (primFanIn > 8)
                    {
                        HDLOutFile.Write("-- ***********\n");
                        HDLOutFile.Write("-- LogicCircuit Component {0} with fan-in of {1} will fail to compile as a Xilinx prim.\n", HDLpartList[j].partName, HDLpartList[j].primWidth);
                        HDLOutFile.Write("-- Xilinx prim fan-in must be <= 8.\n");
                        HDLOutFile.Write("-- Replace LogicCircuit component {0} with a lower-level implementation of {0}{1}.\n", HDLpartList[j].partName, HDLpartList[j].primWidth);
                        HDLOutFile.Write("-- ***********\n");
                        capPartName = VHDLReplaceReservedWord(capPartName) + HDLpartList[j].primWidth;
                    }
                    else capPartName = VHDLReplaceReservedWord(capPartName);

                    // Change the partname if needed
                    capPartName = CheckName(capPartName, "_", false); // Use underscore, since HDL chokes on dash: '-'

                    HDLOutFile.Write("U" + HDLpartList[j].partNum + ": " + capPartName);
                    HDLOutFile.Write(" port map (");

                    // Write the map
                    int last = HDLpartList[j].partPinList.Count - 1;
                    bool sawOne = false;
                    int termCount = 0;

                    for (int i = 0; i < last; i++)
                    {
                        if (sawOne)
                        {
                            HDLOutFile.Write(", ");
                            if (termCount >= 6)
                            {
                                HDLOutFile.WriteLine();
                                HDLOutFile.Write("        ");
                                termCount = 0;
                            }
                            sawOne = false;
                        }
                        if (HDLwireList.ContainsKey(HDLpartList[j].partPinList[i].pinAbsLoc))
                        {
                            // fix boolean and clock pin names
                            string RightSide = HDLProcessWireName(HDLwireList[HDLpartList[j].partPinList[i].pinAbsLoc], true, false);
                            if (RightSide == "clk")
                            {
                                RightSide = "clk";
                            }
                            else if (RightSide == "true")
                            {
                                if (HDLpartList[j].partPinList[i].pinWidth == 1)
                                {
                                    RightSide = "'1'";
                                }
                                else
                                {
                                    RightSide = "\"1";
                                    for (int k = 1; k < HDLpartList[j].partPinList[i].pinWidth; k++)
                                    {
                                        RightSide += "1";
                                    }
                                    RightSide += "\"";
                                }
                            }
                            else if (RightSide == "false")
                            {
                                if (HDLpartList[j].partPinList[i].pinWidth == 1)
                                {
                                    RightSide = "'0'";
                                }
                                else
                                {
                                    RightSide = "\"0";
                                    for (int k = 1; k < HDLpartList[j].partPinList[i].pinWidth; k++)
                                    {
                                        RightSide += "0";
                                    }
                                    RightSide += "\"";
                                }
                            }
                            // If the component maps to a Xilinx primitive (i.e., its name is an HDLXilinxNames dictionary value),
                            // we have to rename the pins in the port map to correspond to the pin names of the Xilinx primitive. 
                            // All pin widths of the Xilinx primitives (at least the ones we are using) are single bit width.

                            string leftName = HDLpartList[j].partPinList[i].pinName;
                            string rootName = new String(HDLpartList[j].partName.TakeWhile(Char.IsLetter).ToArray());
                            if ((HDLXilinxNames.ContainsValue(rootName) || (rootName == "MUXF")) && ((primFanIn > 0) && (primFanIn <= 5))) // "MUXF" the root for "MUXF7"
                            { // we need to map pin names
                                leftName = XilinxMapPinName(leftName, HDLpartList[j].partName);
                                HDLOutFile.Write(leftName + " => " + VHDLReplaceReservedWord(RightSide));
                            }
                            else
                            {
                                HDLOutFile.Write(VHDLReplaceReservedWord(HDLpartList[j].partPinList[i].pinName) + " => " + VHDLReplaceReservedWord(RightSide));
                            }
                            sawOne = true;
                            termCount++;
                        }
                        else throw new CircuitException(Cause.UserError,
                                string.Format(CultureInfo.InvariantCulture,
                                "HDLwireList did not have an entry for {0} on Part {1} at {2}",
                                HDLpartList[j].partPinList[i].pinAbsLoc, HDLpartList[j].partName, HDLpartList[j].partLoc));
                    }
                    //Now the last one
                    if (sawOne) HDLOutFile.Write(", ");
                    if (termCount >= 6)
                    {
                        HDLOutFile.WriteLine();
                        HDLOutFile.Write("        ");
                    }
                    if (HDLwireList.ContainsKey(HDLpartList[j].partPinList[last].pinAbsLoc))
                    {
                        string RightSide = HDLProcessWireName(HDLwireList[HDLpartList[j].partPinList[last].pinAbsLoc], true, false);
                        // fix boolean and clock pin names
                        if (RightSide == "clk")
                        {
                            RightSide = "clk";
                        }
                        else if (RightSide == "true")
                        {
                            if (HDLpartList[j].partPinList[last].pinWidth == 1)
                            {
                                RightSide = "'1'";
                            }
                            else
                            {
                                RightSide = "\"1";
                                for (int k = 1; k < HDLpartList[j].partPinList[last].pinWidth; k++)
                                {
                                    RightSide += "1";
                                }
                                RightSide += "\"";
                            }
                        }
                        else if (RightSide == "false")
                        {
                            if (HDLpartList[j].partPinList[last].pinWidth == 1)
                            {
                                RightSide = "'0'";
                            }
                            else
                            {
                                RightSide = "\"0";
                                for (int k = 1; k < HDLpartList[j].partPinList[last].pinWidth; k++)
                                {
                                    RightSide += "0";
                                }
                                RightSide += "\"";
                            }
                        }

                        // If the component maps to a Xilinx primitive (i.e., its name is an HDLXilinxNames dictionary value),
                        // we have to rename the pins in the port map to correspond to the pin names of the Xilinx primitive. 
                        // All pin widths of the Xilinx primitives (at least the ones we are using) are single bit width.
                        string leftName = HDLpartList[j].partPinList[last].pinName;
                        string rootName = new String(HDLpartList[j].partName.TakeWhile(Char.IsLetter).ToArray());
                        if ((HDLXilinxNames.ContainsValue(rootName) || (rootName == "MUXF")) && ((primFanIn > 0) && (primFanIn <= 5))) // the root for "MUXF7"
                        { // we need to map pin names
                            leftName = XilinxMapPinName(leftName, HDLpartList[j].partName);
                            //HDLOutFile.WriteLine(pnm + " => " + VHDLReplaceReservedWord(RightSide) + ", ");
                        }

                        // If this component is an N2T part with an implicit clock, map it to clk
                        if (HDL_Enforce_N2T_Compatibility && HDL_N2T_Parts_With_Implicit_Clock.Contains(HDLpartList[j].partName.ToLower()))
                        {
                            HDLOutFile.Write(VHDLReplaceReservedWord(leftName) + " => " + VHDLReplaceReservedWord(RightSide) + ", ");
                            if (HDLpartList[j].partName != "FD")
                                HDLOutFile.WriteLine("clk" + " => " + "clk" + ");");
                            else
                                HDLOutFile.WriteLine("C" + " => " + "clk" + ");");
                        }
                        else
                        {
                            HDLOutFile.WriteLine(VHDLReplaceReservedWord(leftName) + " => " + VHDLReplaceReservedWord(RightSide) + ");");
                        }
                    }
                    else throw new CircuitException(Cause.UserError,
                           string.Format(CultureInfo.InvariantCulture,
                           "HDLwireList did not have an entry for {0} on Part {1} at {2}",
                            HDLpartList[j].partPinList[last].pinAbsLoc, HDLpartList[j].partName, HDLpartList[j].partLoc));
                }
            HDLOutFile.WriteLine();
        }

        private void VHDLwriteConcurrentStatements()
        {
            if (HDLconcurrentStatements.Count > 0)
            {
                HDLOutFile.WriteLine("-- Concurrent Assignment Statements");
                foreach (string term in HDLconcurrentStatements)
                {
                    HDLOutFile.WriteLine(term);
                }
            }
        }

        private static string VHDLReplaceReservedWord(string name)
        {
            name = name.Replace("-", "_"); // dashes are problematic in VHDL
            if (name == "open") return name;

            if (HDL_VHDLReservedWords.Contains(name.ToLower())) return ("v_" + name);

            // While not strictly VHDL reserved words, certain names will cause Vivado to try to invoke Xilinx primitives,
            // and others will cause Vivado to try to invoke Xilinx macros. We want to allow the former, and prevent the latter.
            // Thus we handle them here to avoid a naming conflict with Xilinx macros.
            // There are four naming schemes in play: N2T, Xilinx, VHDL, and Verilog. Our resolution:
            //      <primname><blank to 5> is a multi-input gate of type primname supported as a Xilinx primitive.
            //      <primname><6 to 8> is a multi-input gate of type primname but not supported as a Xilinx primitive.
            //      <primname><9 to 16> is either a multi-input gate of type primname, but not supported as a Xilinx primitive, OR
            //        some other circuit as defined by the user (we just rename it so as  not to try to invoke a Xilinx macro).
            // NOTE: We raise an error if the user actually tries to use a LC prim with a width > 8. 
            //      In this implementation, <primnames><13 and 16> are modules with 13/16 2-input gates of type primname.
            string rootName = new String(name.TakeWhile(Char.IsLetter).ToArray());
            int numIdx = name.IndexOfAny("16789".ToCharArray()); // suffices "6" to "16"
            int num = -1;
            if (numIdx > 0)
            {
                bool ok = Int32.TryParse(name.Substring(numIdx), out num);
                if (HDL_VHDLReservedWords.Contains(rootName.ToLower()) && ((num >= 6) && (num <= 16)))
                {
                    return ("v_" + name);
                }
            }
            return name;
        }

    }
}