﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 * 
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;
using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
// using Microsoft.Win32; // We use this library, but only explicitly to avoid ambiguity with System.Windows.Forms
using System.Windows.Forms;

namespace LogicCircuit
{
    public partial class CircuitProject
    {
        // This list helps us avoid producing a Verilog reserved word as a name
        // It includes reserved words from all versions of Verilog (including SystemVerilog)
        private static readonly List<string> VerilogReservedWords = new List<string>()
        {
            {"accept_on"}, {"alias"}, {"always"}, {"always_comb"}, {"always_ff"}, {"always_latch"}, {"and"},
            {"assert"}, {"assign"}, {"assume"}, {"automatic"}, {"before"}, {"begin"}, {"bind"}, {"bins"},
            {"binsof"}, {"bit"}, {"break"}, {"buf"}, {"bufif0"}, {"bufif1"}, {"byte"}, {"case"}, {"casex"},
            {"casez"}, {"cell"}, {"chandle"}, {"checker"}, {"class"}, {"clocking"}, {"cmos"}, {"config"},
            {"const"}, {"constraint"}, {"context"}, {"continue"}, {"cover"}, {"covergroup"}, {"coverpoint"},
            {"cross"}, {"deassign"}, {"default"}, {"defparam"}, {"disable"}, {"dist"}, {"do"}, {"edge"},
            {"else"}, {"end"}, {"endcase"}, {"endchecker"}, {"endclass"}, {"endclocking"}, {"endconfig"},
            {"endfunction"}, {"endgenerate"}, {"endgroup"}, {"endinterface"}, {"endmodule"}, {"endpackage"},
            {"endprimitive"}, {"endprogram"}, {"endproperty"}, {"endsequence"}, {"endspecify"}, {"endtable"},
            {"endtask"}, {"enum"}, {"event"}, {"eventually"}, {"expect"}, {"export"}, {"extends"}, {"extern"},
            {"final"}, {"first_match"}, {"for"}, {"force"}, {"foreach"}, {"forever"}, {"fork"}, {"forkjoin"},
            {"function"}, {"generate"}, {"genvar"}, {"global"}, {"highz0"}, {"highz1"}, {"if"}, {"iff"},
            {"ifnone"}, {"ignore_bins"}, {"illegal_bins"}, {"implies"}, {"import"}, {"incdir"}, {"include"},
            {"initial"}, {"inout"}, {"input"}, {"inside"}, {"instance"}, {"int"}, {"integer"}, {"interface"},
            {"intersect"}, {"join"}, {"join_any"}, {"join_none"}, {"large"}, {"let"}, {"liblist"}, {"library"},
            {"local"}, {"localparam"}, {"logic"}, {"longint"}, {"macromodule"}, {"matches"}, {"medium"},
            {"modport"}, {"module"}, {"nand"}, {"negedge"}, {"new"}, {"nexttime"}, {"nmos"}, {"nor"},
            {"noshowcancelled"}, {"not"}, {"notif0"}, {"notif1"}, {"null"}, {"or"}, {"output"}, {"package"},
            {"packed"}, {"parameter"}, {"pmos"}, {"posedge"}, {"primitive"}, {"priority"}, {"program"},
            {"property"}, {"protected"}, {"pull0"}, {"pull1"}, {"pulldown"}, {"pullup"},
            {"pulsestyle_ondetect"}, {"pulsestyle_onevent"}, {"pure"}, {"rand"}, {"randc"},
            {"randcase"}, {"randsequence"}, {"rcmos"}, {"real"}, {"realtime"}, {"ref"}, {"reg"},
            {"reject_on"}, {"release"}, {"repeat"}, {"restrict"}, {"return"}, {"rnmos"}, {"rpmos"},
            {"rtran"}, {"rtranif0"}, {"rtranif1"}, {"s_always"}, {"s_eventually"}, {"s_nexttime"},
            {"s_until"}, {"s_until_with"}, {"scalared"}, {"sequence"}, {"shortint"}, {"shortreal"},
            {"showcancelled"}, {"signed"}, {"small"}, {"solve"}, {"specify"}, {"specparam"}, {"static"},
            {"string"}, {"strong"}, {"strong0"}, {"strong1"}, {"struct"}, {"super"}, {"supply0"},
            {"supply1"}, {"sync_accept_on"}, {"sync_reject_on"}, {"table"}, {"tagged"}, {"task"}, {"this"},
            {"throughout"}, {"time"}, {"timeprecision"}, {"timeunit"}, {"tran"}, {"tranif0"}, {"tranif1"},
            {"tri"}, {"tri0"}, {"tri1"}, {"triand"}, {"trior"}, {"trireg"}, {"type"}, {"typedef"},
            {"union"}, {"unique"}, {"unique0"}, {"unsigned"}, {"until"}, {"until_with"}, {"untypted"},
            {"use"}, {"var"}, {"vectored"}, {"virtual"}, {"void"}, {"wait"}, {"wait_order"}, {"wand"},
            {"weak"}, {"weak0"}, {"weak1"}, {"while"}, {"wildcard"}, {"wire"}, {"with"}, {"within"},
            {"wor"}, {"xnor"}, {"xor"},
            // Not actual Verilog reserved words, but included here to avoid potential naming conflict with Xilinx macros
            {"mux"}, {"add"}
        };

        // One of three entry points from the LC user interface: "Save as Verilog..."
        public void WriteVerilogFile()
        {
            // For Verilog, we have the option of just saving the current circuit,
            // or saving all circuits in the project.
            DialogResult dialogResult = MessageBox.Show("Save all circuits in this project as Verilog?", "Inclusive Save?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                WriteVerilogFileInclusive();
            }
            else if (dialogResult == DialogResult.No)
            {
                WriteVerilogFileNR(this.ProjectSet.Project.LogicalCircuit, ""); // empty string as the directory name means single circuit save
            }
        }

        // Save all circuits in this project as Verilog
        private void WriteVerilogFileInclusive()
        {
            string hdlSavePath = "";
            FolderBrowserDialog fbd = new FolderBrowserDialog
            {
                Description = "Choose (or create) folder where all Verilog files will be saved",
                RootFolder = Environment.SpecialFolder.Desktop // default
            };
            DialogResult dirResult = fbd.ShowDialog();
            if (dirResult == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
            {
                if (fbd.SelectedPath == Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) // user did not specify a directory, so specify one for them (in the current directory)
                {
                    hdlSavePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\VERILOG_SAVE_DIR";
                }
                else // the user completed the dialog selection, so use what they entered
                {
                    // Is this a legal directory path name? If not, fix it
                    hdlSavePath = CheckName(fbd.SelectedPath, "_"); // Use underscore for Verilog (which chokes on dash) 
                }
            }
            else // if all else fails, just specify a directory
            {
                hdlSavePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\VERILOG_SAVE_DIR";
            }
            if (!Directory.Exists(hdlSavePath)) // if the directory does not exist, create it
            {
                Directory.CreateDirectory(hdlSavePath);
            }
            foreach (LogicalCircuit logicalCkt in this.LogicalCircuitSet)
            {
                WriteVerilogFileNR(logicalCkt, hdlSavePath);
            }
            fbd.Dispose();
        }

        // Save single circuit as Verilog
        private void WriteVerilogFileNR(LogicalCircuit logCkt, string dirName)
        {
            HDLinPinList = new List<HDLpin>();
            HDLoutPinList = new List<HDLpin>();
            HDLProjectPinDirection = new Dictionary<string, string>();
            HDLpartList = new List<HDLpart>();
            HDLwireList = new Dictionary<GridPoint, string>();
            HDLsignalsList = new Dictionary<string, int>();
            HDLconcurrentStatements = new List<string>();
            HDLnameInt = -1;    // used to build unique wire names when needed
            HDLnumOpenPins = 0; // unused output pins
            HDLnumUnusedPins = 0;   // unused input pins
            HDLnumRegularParts = 0;
            HDLnumSplitterParts = 0;
            HDLwtbNameInt = -1;
            HDLsrcInt = -1;
            HDLclockDefined = false;
            string fname = "";

            try
            {
                HDLprojectName = logCkt.Name;            // the working name of this circuit project during translation
                HDLOrigprojectName = HDLprojectName;     // the original name of this circuit project               
                if (HDLprojectName.ToLower() == "pc") HDLprojectName = "PC_Register";
                HDLprojCktID = logCkt.LogicalCircuitId;

                // Is this a legal file name? If not, fix it
                HDLprojectName = CheckName(HDLprojectName, "_"); // Use underscore, since Verilog chokes on dash: '-'

                if (dirName.Length == 0) // not inclusive save
                {
                    Microsoft.Win32.SaveFileDialog dialog = new Microsoft.Win32.SaveFileDialog
                    {
                        Title = "Save this circuit as Structural Verilog .v file",
                        DefaultExt = ".v",
                        FileName = HDLprojectName,
                        Filter = "Verilog files (*.v)|*.v|All files (*.*)|*.*",
                        FilterIndex = 1,
                        RestoreDirectory = true,
                        InitialDirectory = Mainframe.DefaultProjectFolder(),
                        CheckPathExists = true
                    };
                    bool? result = dialog.ShowDialog();
                    if (result.HasValue && result.Value)
                    {
                        try
                        {
                            // Is this a legal file name? If not, fix it
                            fname = CheckName(dialog.FileName, "_"); // Use underscore for Verilog (which chokes on dash) 
                            HDLOutFile = new StreamWriter(fname);
                        }
                        catch
                        {
                            // The filename is invalid; this code should not be executed since we fixed the name
                            throw new CircuitException(Cause.UserError,
                                   string.Format(CultureInfo.InvariantCulture,
                                   "Circuit Names must be valid Windows filename prefixes." + "\n" +
                                   "Rename Circuit {0} to be a valid filename prefix.", dialog.FileName));
                        }
                    }
                    else
                    {
                        throw new CircuitException(Cause.UserError,
                           string.Format(CultureInfo.InvariantCulture, "Unable to create file."));
                    }
                }
                else // inclusive save
                {
                    try
                    {
                        // Is this a legal file name? If not, fix it
                        fname = CheckName(logCkt.Name, "_"); // Use underscore for Verilog (which chokes on dash) 
                        HDLOutFile = new StreamWriter(dirName + "\\" + fname + ".v");
                    }
                    catch
                    {
                        // We shouldn't see this exception since we fixed the name
                        // The filename is invalid
                        throw new CircuitException(Cause.UserError,
                               string.Format(CultureInfo.InvariantCulture,
                               "Circuit Names must be valid Windows filename prefixes." + "\n" +
                               "Rename Circuit {0} to be a valid filename prefix.", logCkt.Name));
                    }
                }
                // Write Verilog Header
                HDLOutFile.WriteLine("// This file was generated from LogicCircuit CircuitProject: {0}", HDLOrigprojectName);
                if (HDLOrigprojectName != HDLprojectName)
                {
                    HDLOutFile.WriteLine("// During translation, CircuitProject name '{0}' was converted to '{1}'.", HDLOrigprojectName, HDLprojectName);
                    HDLOutFile.WriteLine("// You may wish to make this change in LogicCircuit to ensure future compatibility.");
                }
                HDLOutFile.WriteLine("// Please report issues to jkb@colorado.edu");
                HDLOutFile.WriteLine("// {0}", DateTime.Now.ToString());
                //HDLOutFile.WriteLine("// Disable implicit net creation");
                //HDLOutFile.WriteLine("`default_nettype none");
                HDLOutFile.WriteLine();

                HDLOutFile.Write("module {0} (", VerilogReplaceReservedWord(HDLprojectName));

                if (HDLAnalyzeCircuit(/*VHDL*/ false, /*VERILOG*/ true, logCkt, dirName))
                    // Output to Verilog file
                    VerilogCreateFile();
            }
            catch (Exception exception)
            {
                App.Mainframe.ReportException(exception);
            }
        }

        private void VerilogCreateFile()
        {
            VerilogWritePorts();
            VerilogWriteWires();
            VerilogWriteParts();
            VerilogWriteAssignments();
            // Write Verilog Footer
            HDLOutFile.WriteLine("endmodule");
            HDLOutFile.Close();
        }

        private void VerilogWritePorts()
        {
            // First finish the module declaration
            // At this point, we have written "Module <name> ("
            // In Verilog, we name all of the ports in the module statement, then we size and type them within the 
            // module itself (like C)

            // Find all of the input pins
            // These are indentified by having an assigned input pin on the schematic
            // Verilog does not uses implied clocks, so these must be declared in the Verilog file

            // declare all of the named pins of this chip -- we don;t care about size or direction at this point

            for (int i = 0; i < HDLinPinList.Count; i++)
            {
                HDLOutFile.Write(VerilogReplaceReservedWord(HDLinPinList[i].pinName) + ", ");
            }

            // Find all of the output pins
            // These are indentified by having an assigned output pin on the schematic
            int numPinsWritten = 0;
            for (int i = 0; i < HDLoutPinList.Count; i++)
            {
                HDLOutFile.Write(VerilogReplaceReservedWord(HDLoutPinList[i].pinName));
                numPinsWritten++;
                if (numPinsWritten < HDLoutPinList.Count) HDLOutFile.Write(", ");
                else HDLOutFile.WriteLine(");");
            }

            // Now we actually have to identify direction and size for all inputs and outputs

            // Find all of the input pins
            // These are indentified by having an assigned input pin on the schematic
            // Verilog does not uses implied clocks, so these must be declared in the Verilog file
            HDLOutFile.WriteLine("// Module inputs and outputs");

            // declare all of the named pins of this chip -- yes this is inefficient
            // do the one-bit IN's first
            for (int i = 0; i < HDLinPinList.Count; i++)
            {
                if (HDLinPinList[i].pinWidth == 1) HDLOutFile.WriteLine("input "
                        + VerilogReplaceReservedWord(HDLinPinList[i].pinName)
                        + ";");
            }

            // now do the multibit IN's
            for (int i = 0; i < HDLinPinList.Count; i++)
            {
                if (HDLinPinList[i].pinWidth > 1)
                    HDLOutFile.WriteLine("input [{0}:0] {1};", HDLinPinList[i].pinWidth - 1, VerilogReplaceReservedWord(HDLinPinList[i].pinName));
            }

            // Find all of the output pins
            // These are indentified by having an assigned output pin on the schematic
            // do the one-bit OUT's
            for (int i = 0; i < HDLoutPinList.Count; i++)
            {
                if (HDLoutPinList[i].pinWidth == 1)
                {
                    HDLOutFile.WriteLine("output " + VerilogReplaceReservedWord(HDLoutPinList[i].pinName) + ";");
                }
            }

            // now do the multibit OUT's
            for (int i = 0; i < HDLoutPinList.Count; i++)
            {
                if (HDLoutPinList[i].pinWidth > 1)
                {
                    HDLOutFile.WriteLine("output [{0}:0] {1};", HDLoutPinList[i].pinWidth - 1,
                        VerilogReplaceReservedWord(HDLoutPinList[i].pinName));
                }
            }
            HDLOutFile.WriteLine();
        }

        private void VerilogWriteWires()
        {
            if (HDLsignalsList.Count > 0)
            {
                HDLOutFile.WriteLine("// Wires");
                foreach (KeyValuePair<string, int> kvp in HDLsignalsList)
                {
                    if (kvp.Value == 1) HDLOutFile.WriteLine("wire {0};", kvp.Key);
                    else HDLOutFile.WriteLine("wire [{0}:0] {1};", kvp.Value - 1, kvp.Key);
                }
                HDLOutFile.WriteLine();
            }
        }

        private void VerilogWriteParts()
        {
            HDLOutFile.WriteLine("// Components and Component Port Maps");
            for (int j = 0; j < HDLpartList.Count; j++)
                // only the "regular" parts are components whose ports get mapped
                if (HDLpartList[j].partType == HDLPartType.RegularPart)
                {
                    bool ok = Int32.TryParse(HDLpartList[j].primWidth, out int primFanIn);
                    string pName = HDLpartList[j].partName;
                    string capPartName = pName;
                    if (Char.IsLetter(pName.First())) capPartName = pName.First().ToString().ToUpper() + pName.Substring(1);
                    if (HDL_Enforce_N2T_Compatibility && HDLN2TNames.ContainsKey(capPartName)) capPartName = HDLN2TNames[capPartName]; // make the part name match N2T part name
                    if (capPartName == "PC") capPartName = "PC_Register";
                    if ((primFanIn > 5) && (primFanIn <= 8))
                        capPartName = VerilogReplaceReservedWord(capPartName) + HDLpartList[j].primWidth;
                    else if (primFanIn > 8)
                    {
                        HDLOutFile.WriteLine("// ***********");
                        HDLOutFile.WriteLine("// LogicCircuit Component {0} with fan-in of {1} will fail to compile as a Xilinx prim.", HDLpartList[j].partName, HDLpartList[j].primWidth);
                        HDLOutFile.WriteLine("// Xilinx prim fan-in must be <= 8.");
                        HDLOutFile.WriteLine("// Replace LogicCircuit component {0} with a lower-level implementation of {0}{1}.", HDLpartList[j].partName, HDLpartList[j].primWidth);
                        HDLOutFile.WriteLine("// ***********");
                        capPartName = VerilogReplaceReservedWord(capPartName) + HDLpartList[j].primWidth;

                        // we are producing a part that will not compile, so tell the user
                        string message = string.Format(CultureInfo.InvariantCulture,
                               "Xilinx Prim {0} fan-in of {1} is too large (must be <= 8).\n This component will fail to compile with Xilinx tools." + "\n", HDLpartList[j].partName, HDLpartList[j].primWidth);
                        string title = "Warning";
                        MessageBox.Show(message, title);
                    }
                    else capPartName = VerilogReplaceReservedWord(capPartName);

                    // Change the partname if needed
                    capPartName = CheckName(capPartName, "_", false); // Use underscore, since HDL chokes on dash: '-'

                    HDLOutFile.Write(capPartName + " U" + HDLpartList[j].partNum + "(");

                    // Write the map
                    int last = HDLpartList[j].partPinList.Count - 1;
                    bool sawOne = false;
                    int termCount = 0;

                    for (int i = 0; i < last; i++)
                    {
                        if (sawOne)
                        {
                            HDLOutFile.Write(", ");
                            if (termCount >= 6)
                            {
                                HDLOutFile.WriteLine();
                                HDLOutFile.Write("        ");
                                termCount = 0;
                            }
                            sawOne = false;
                        }
                        if (HDLwireList.ContainsKey(HDLpartList[j].partPinList[i].pinAbsLoc))
                        {
                            // fix boolean and clock pin names
                            string RightSide = HDLProcessWireName(HDLwireList[HDLpartList[j].partPinList[i].pinAbsLoc], false, true);
                            if (RightSide == "clk")
                            {
                                RightSide = "clk";
                            }
                            else if (RightSide == "true")
                            {
                                if (HDLpartList[j].partPinList[last].pinWidth == 1)
                                {
                                    RightSide = "1\'b1";
                                }
                                else
                                {
                                    RightSide = "1\'b1";
                                    for (int k = 1; k < HDLpartList[j].partPinList[last].pinWidth; k++)
                                    {
                                        RightSide += "1";
                                    }
                                }
                            }
                            else if (RightSide == "false")
                            {
                                if (HDLpartList[j].partPinList[last].pinWidth == 1)
                                {
                                    RightSide = "1\'b0";
                                }
                                else
                                {
                                    RightSide = "1\'b0";
                                    for (int k = 1; k < HDLpartList[j].partPinList[last].pinWidth; k++)
                                    {
                                        RightSide += "0";
                                    }
                                }
                            }
                            // If the component maps to a Xilinx primitive (i.e., its name is an HDLXilinxNames dictionary value),
                            // we have to rename the pins in the port map to correspond to the pin names of the Xilinx primitive. 
                            // All pin widths of the Xilinx primitives (at least the ones we are using) are single bit width.

                            string leftName = HDLpartList[j].partPinList[i].pinName;
                            string rootName = new String(HDLpartList[j].partName.TakeWhile(Char.IsLetter).ToArray());
                            if ((HDLXilinxNames.ContainsValue(rootName) || (rootName == "MUXF")) && ((primFanIn > 0) && (primFanIn <= 5))) // "MUXF" the root for "MUXF7"
                            { // we need to map pin names
                                leftName = XilinxMapPinName(leftName, HDLpartList[j].partName);
                                HDLOutFile.Write("." + leftName + "(" + VerilogReplaceReservedWord(RightSide) + ")");
                            }
                            else
                            {
                                HDLOutFile.Write(VerilogReplaceReservedWord("." + HDLpartList[j].partPinList[i].pinName) + "(" + VerilogReplaceReservedWord(RightSide) + ")");
                            }
                            sawOne = true;
                            termCount++;
                        }
                        else throw new CircuitException(Cause.UserError,
                                string.Format(CultureInfo.InvariantCulture,
                                "HDLwireList did not have an entry for {0} on Part {1} at {2}",
                                HDLpartList[j].partPinList[i].pinAbsLoc, HDLpartList[j].partName, HDLpartList[j].partLoc));
                    }
                    //Now the last one
                    if (sawOne) HDLOutFile.Write(", ");
                    if (termCount >= 6)
                    {
                        HDLOutFile.WriteLine();
                        HDLOutFile.Write("        ");
                    }
                    if (HDLwireList.ContainsKey(HDLpartList[j].partPinList[last].pinAbsLoc))
                    {
                        string RightSide = HDLProcessWireName(HDLwireList[HDLpartList[j].partPinList[last].pinAbsLoc], false, true);
                        // fix boolean and clock pin names
                        if (RightSide == "clk")
                        {
                            RightSide = "clk";
                        }
                        else if (RightSide == "true")
                        {
                            if (HDLpartList[j].partPinList[last].pinWidth == 1)
                            {
                                RightSide = "1\'b1";
                            }
                            else
                            {
                                RightSide = "1\'b1";
                                for (int k = 1; k < HDLpartList[j].partPinList[last].pinWidth; k++)
                                {
                                    RightSide += "1";
                                }
                            }
                        }
                        else if (RightSide == "false")
                        {
                            if (HDLpartList[j].partPinList[last].pinWidth == 1)
                            {
                                RightSide = "1\'b0";
                            }
                            else
                            {
                                RightSide = "1\'b0";
                                for (int k = 1; k < HDLpartList[j].partPinList[last].pinWidth; k++)
                                {
                                    RightSide += "0";
                                }
                            }
                        }

                        // If the component maps to a Xilinx primitive (i.e., its name is an HDLXilinxNames dictionary value),
                        // we have to rename the pins in the port map to correspond to the pin names of the Xilinx primitive. 
                        // All pin widths of the Xilinx primitives (at least the ones we are using) are single bit width.
                        string leftName = HDLpartList[j].partPinList[last].pinName;
                        string rootName = new String(HDLpartList[j].partName.TakeWhile(Char.IsLetter).ToArray());
                        if ((HDLXilinxNames.ContainsValue(rootName) || (rootName == "MUXF")) && ((primFanIn > 0) && (primFanIn <= 5))) // the root for "MUXF7"
                        { // we need to map pin names
                            leftName = XilinxMapPinName(leftName, HDLpartList[j].partName);
                        }

                        // If this component is an N2T part with an implicit clock, map it to clk
                        if (HDL_Enforce_N2T_Compatibility && HDL_N2T_Parts_With_Implicit_Clock.Contains(HDLpartList[j].partName.ToLower()))
                        {
                            HDLOutFile.Write("." + VerilogReplaceReservedWord(leftName) + "(" + VerilogReplaceReservedWord(RightSide) + "), ");
                            if (HDLpartList[j].partName != "FD")
                                HDLOutFile.WriteLine(".clk" + "(" + "clk)" + ");");
                            else
                                HDLOutFile.WriteLine(".C" + "(" + "clk)" + ");");
                        }
                        else
                        {
                            HDLOutFile.WriteLine("." + VerilogReplaceReservedWord(leftName) + "(" + VerilogReplaceReservedWord(RightSide) + "));");
                        }
                    }
                    else throw new CircuitException(Cause.UserError,
                           string.Format(CultureInfo.InvariantCulture,
                           "HDLwireList did not have an entry for {0} on Part {1} at {2}",
                            HDLpartList[j].partPinList[last].pinAbsLoc, HDLpartList[j].partName, HDLpartList[j].partLoc));
                }

            HDLOutFile.WriteLine();
        }

        private void VerilogWriteAssignments()
        {
            if (HDLconcurrentStatements.Count > 0)
            {
                HDLOutFile.WriteLine("// Assign Statements");
                foreach (string verilogTerm in HDLconcurrentStatements)
                {
                    HDLOutFile.WriteLine(verilogTerm);
                }
            }
        }

        private static string VerilogReplaceReservedWord(string name)
        {
            name = name.Replace("-", "_"); // dashes are problematic in Verilog
            if (name == "open") return name;

            if (VerilogReservedWords.Contains(name.ToLower())) return ("v_" + name);

            // While not strictly VHDL reserved words, certain names will cause Vivado to try to invoke Xilinx primitives,
            // and others will cause Vivado to try to invoke Xilinx macros. We want to allow the former, and prevent the latter.
            // Thus we handle them here to avoid a naming conflict with Xilinx macros.
            // There are three naming schemes in play: N2T, Xilinx, VHDL, and Verilog. Our resolution:
            //      <primname><blank to 5> is a multi-input gate of type primname supported as a Xilinx primitive.
            //      <primname><6 to 8> is a multi-input gate of type primname but not supported as a Xilinx primitive.
            //      <primname><9 to 16> is either a multi-input gate of type primname, but not supported as a Xilinx primitive, OR
            //        some other circuit as defined by the user (we just rename it so as  not to try to invoke a Xilinx macro).
            // NOTE: We raise an error if the user actually tries to use a LC prim with a width > 8. 
            //      In this implementation, <primnames><13 and 16> are modules with 13/16 2-input gates of type primname.
            string rootName = new String(name.TakeWhile(Char.IsLetter).ToArray());
            int numIdx = name.IndexOfAny("16789".ToCharArray()); // suffices "6" to "16"
            int num = -1;
            if (numIdx > 0)
            {
                bool ok = Int32.TryParse(name.Substring(numIdx), out num);
                if (VerilogReservedWords.Contains(rootName.ToLower()) && ((num >= 6) && (num <= 16)))
                {
                    return ("v_" + name);
                }
            }
            return name;
        }

    }
}