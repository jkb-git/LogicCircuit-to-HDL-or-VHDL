﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 *  
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;
using System.Diagnostics.CodeAnalysis;
using System.Windows.Input;

namespace LogicCircuit
{
    public partial class FunctionRam : FunctionMemory
    {
        [SuppressMessage("Microsoft.Usage", "CA2211: Non-constant fields should not be visible")]
        public static FunctionRam keyboardRAM;
        private bool shiftKeyPressed; // this is here so we can remember the shift key for Keyboard emulation
        private bool capsLockPressed = false; // this is here so we can remember the caps lock key for Keyboard emulation
        private bool sawKeyNoneAfterCapsLock = true;

        public bool WriteKeyValue(Key keyBeingPressed)
        {
            // if keyboard sim is enabled set, put the ASCII value of the key being pressed into memory
            // at location zero (the address memory-mapped to keyboard input)
            // return true if all OK
            if (keyBeingPressed == Key.None)
            {
                sawKeyNoneAfterCapsLock = true;
                if (shiftKeyPressed) shiftKeyPressed = false;
                if (this.Memory.MapKeyboard == MemoryMapKeyboard.Hack)
                {
                    Memory.SetCellValue(this.data, 16, 0, 0);
                    return (true);
                }
            }

            short rawKeyValue = (short)keyBeingPressed;
            short ASCIIKeyValue = 0;

            if (keyBeingPressed == Key.Capital) // raw code 0x0008
            {
                if (sawKeyNoneAfterCapsLock)
                {
                    capsLockPressed = !capsLockPressed;
                    sawKeyNoneAfterCapsLock = false;
                }
            }
            if ((keyBeingPressed == Key.LeftShift) || (keyBeingPressed == Key.RightShift))
            {
                shiftKeyPressed = true; // remember while some other key is pressed 
            }

            // Translate the Key enumeration into ASCII
            // Take the hex code the keyboard gives us, and depending upon whether the shift key was just pressed, 
            // output the correct ASCII code for the key.  In some cases, we use the Hack Computer book settings 
            // (see page 91 of Nisan and Schocken).
            // We use a custom dictionary lookup to determine the value

            // If different keyboards use different key to hex mappings, we will need custom dictionaries for each.
            // All unmapped values return 0

            // add 0x100 to the raw code if shifted or caps-locked.
            if (shiftKeyPressed || capsLockPressed)
            {
                rawKeyValue += 0x100;
            }

            if (HDLKeyMapTable.keyMap.ContainsKey(rawKeyValue))
            {
                ASCIIKeyValue = HDLKeyMapTable.keyMap[rawKeyValue];
            }
            else ASCIIKeyValue = 0;

            if (this.Memory.MapKeyboard == MemoryMapKeyboard.Hack)
            {
                Memory.SetCellValue(this.data, 16, 0, ASCIIKeyValue);
                return (true);
            }
            return (false);
        }
    }
}