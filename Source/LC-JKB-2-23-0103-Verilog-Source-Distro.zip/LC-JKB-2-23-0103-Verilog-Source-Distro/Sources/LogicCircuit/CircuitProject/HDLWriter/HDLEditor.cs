﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 *  
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LogicCircuit
{
	[SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
	public partial class Editor : EditorDiagram, INotifyPropertyChanged
	{
		public void WriteHDLFile()
		{
			this.CircuitProject.WriteHDLFile();
		}

		public void WriteVHDLFile()
		{
			this.CircuitProject.WriteVHDLFile();
		}

		public void WriteVerilogFile()
		{
			this.CircuitProject.WriteVerilogFile();
		}
	}
}