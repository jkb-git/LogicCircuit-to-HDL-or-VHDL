﻿/* LogicCircuit Circuit Project to Nand2Tetris, VHDL, and Verilog translator
 * Copyright 2021-2022, John K. Bennett
 * 
 * With attribution, this software may be used for any non-commercial purpose.
 * Eugene Lepekhin, the author of LogicCircuit who generously shared his source code, may use this software without restriction for any purpose whatsoever.
 *  
 * Please report errors or send comments to jkb@colorado.edu.
 * 
 */

using System;

namespace LogicCircuit {
	public enum MemoryMapKeyboard {
		Disabled,
		Hack,
		Other
	}
}
