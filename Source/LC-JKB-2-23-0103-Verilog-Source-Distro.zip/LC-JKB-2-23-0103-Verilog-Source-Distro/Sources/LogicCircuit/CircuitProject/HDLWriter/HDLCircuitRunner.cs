﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Windows.Threading;
using System.Windows.Input;

namespace LogicCircuit
{
	public partial class CircuitRunner
	{
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		private void RefreshUI()
		{
			try
			{
				if (this.running)
				{
					this.updatingUI = true;

					// see if the user pressed a key (for keyboard emulation)
					Key key = KeyPressed();
					if (key != Key.None)
					{
						// If a key is pressed, and keyboard simulation is enabled, update the memory address
						// assigned to the keyboard with the new value. 
						if (FunctionRam.keyboardRAM != null) FunctionRam.keyboardRAM.WriteKeyValue(key);
					}
					else
					{
						if (FunctionRam.keyboardRAM != null) FunctionRam.keyboardRAM.WriteKeyValue(Key.None);
					}

					Thread.MemoryBarrier();
					this.VisibleMap.Redraw(false);
					if (this.actualFrequency != this.lastActualFrequency)
					{
						this.lastActualFrequency = this.actualFrequency;
						this.Editor.ActualFrequency = this.actualFrequency;
					}
				}
			}
			catch (ThreadAbortException)
			{
			}
			catch (Exception exception)
			{
				this.Editor.Mainframe.ReportException(exception);
			}
			finally
			{
				this.refreshing = false;
				this.updatingUI = false;
				Thread.MemoryBarrier();
			}
		}
 
		private static Key KeyPressed()
		{
			var allPossibleKeys = Enum.GetValues(typeof(Key));
			Key result = Key.None;
			foreach (var currentKey in allPossibleKeys)
			{
				Key key = (Key)currentKey;
				if ((key != Key.None) && (Keyboard.IsKeyDown(key)))
				{
					result = key; break;
				}
			}
			return result;
		}
	}
}