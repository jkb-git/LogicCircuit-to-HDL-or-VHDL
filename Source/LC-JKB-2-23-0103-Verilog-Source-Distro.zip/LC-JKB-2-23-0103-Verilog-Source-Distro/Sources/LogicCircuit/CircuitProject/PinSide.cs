﻿using System;

namespace LogicCircuit {
	public enum PinSide {
		Left,
		Top,
		Right,
		Bottom
	}
}
