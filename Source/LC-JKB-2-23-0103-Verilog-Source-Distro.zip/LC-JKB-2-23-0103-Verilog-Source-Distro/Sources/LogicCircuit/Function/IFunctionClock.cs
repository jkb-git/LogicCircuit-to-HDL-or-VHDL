﻿using System;

namespace LogicCircuit {
	public interface IFunctionClock {
		bool Flip();
	}
}
