﻿using System;


namespace LogicCircuit {
	public partial class FunctionRam : FunctionMemory { // jkb changed to partial for HDL
        public FunctionRam(CircuitState circuitState, int[] address, int[] inputData, int[] outputData, int[] address2, int[] outputData2, int write, Memory memory) : base(
            circuitState, address, inputData, outputData, address2, outputData2, write, memory)
        {
            // jkb: remember this guy if its a keyboard
            if (this.Memory.MapKeyboard == MemoryMapKeyboard.Hack) keyboardRAM = this;
        }

		public override bool Evaluate() {
			if(this.IsWriteAllowed()) {
				this.Write();
			}
			return this.Read();
		}

		public override string ReportName { get { return Properties.Resources.ReportMemoryName(Properties.Resources.RAMNotation, this.AddressBitWidth, this.DataBitWidth); } }
    }
}
