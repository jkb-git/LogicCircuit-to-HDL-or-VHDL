/********************************************************************************
 * The contents of this file are subject to the GNU General Public License      *
 * (GPL) Version 2 or later (the "License"); you may not use this file except   *
 * in compliance with the License. You may obtain a copy of the License at      *
 * http://www.gnu.org/copyleft/gpl.html                                         *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * without warranty of any kind, either expressed or implied. See the License   *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * This file was developed by John Bennett to facilitate the use of LogicCircuit*
 * to design circuits that can be tested using the software suite that supports *
 * the book "The Elements of Computing Systems" by Nisan and Schocken,          *
 * MIT Press 2005. If you modify the contents of this file, please document and *
 * mark your changes clearly, for the benefit of others.                        *
 ********************************************************************************/

package builtInChips;

import Hack.Gates.BuiltInGate;

/**
 * A bitwise 8x4 Buffer gate.
 */
public class Buff8x4 extends BuiltInGate {
	
	private short value = 0;

    protected void reCompute() {
    	short a = inputPins[0].get();
        short b = inputPins[1].get();
        
        value = (short) (a | b<<4 );
        outputPins[0].set(value);
    }
}
