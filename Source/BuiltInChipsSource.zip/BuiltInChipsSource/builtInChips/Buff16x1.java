/********************************************************************************
 * The contents of this file are subject to the GNU General Public License      *
 * (GPL) Version 2 or later (the "License"); you may not use this file except   *
 * in compliance with the License. You may obtain a copy of the License at      *
 * http://www.gnu.org/copyleft/gpl.html                                         *
 *                                                                              *
 * Software distributed under the License is distributed on an "AS IS" basis,   *
 * without warranty of any kind, either expressed or implied. See the License   *
 * for the specific language governing rights and limitations under the         *
 * License.                                                                     *
 *                                                                              *
 * This file was developed by John Bennett to facilitate the use of LogicCircuit*
 * to design circuits that can be tested using the software suite that supports *
 * the book "The Elements of Computing Systems" by Nisan and Schocken,          *
 * MIT Press 2005. If you modify the contents of this file, please document and *
 * mark your changes clearly, for the benefit of others.                        *
 ********************************************************************************/

package builtInChips;

import Hack.Gates.BuiltInGate;

/**
 * A bitwise 16-bit Buffer gate.
 */
public class Buff16x1 extends BuiltInGate {
	
	private short value = 0;

    protected void reCompute() {
    	short a = inputPins[0].get();
        short b = inputPins[1].get();
        short c = inputPins[2].get();
        short d = inputPins[3].get();
        short e = inputPins[4].get();
        short f = inputPins[5].get();
        short g = inputPins[6].get();
        short h = inputPins[7].get();
        short i = inputPins[8].get();
        short j = inputPins[9].get();
        short k = inputPins[10].get();
        short l = inputPins[11].get();
        short m = inputPins[12].get();
        short n = inputPins[13].get();
        short o = inputPins[14].get();
        short p = inputPins[15].get();
        
        value = (short) (a | b<<1 | c<<2 | d<<3 | e<<4 | f<<5 | g<<6 | h<<7 | i<<8 | j<<9 | k<<10 | l<<11 | m<<12 | n<<13 | o<<14 | p<<15);
        outputPins[0].set(value);
    }
}
