﻿using System;

namespace ItemWrapper.Generator {
	public enum AccessModifier {
		Public,
		Internal,
		Protected,
		Private,
	}
}
