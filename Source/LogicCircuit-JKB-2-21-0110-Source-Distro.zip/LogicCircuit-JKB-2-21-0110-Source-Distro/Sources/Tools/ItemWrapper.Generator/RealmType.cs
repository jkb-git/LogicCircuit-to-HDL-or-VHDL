﻿using System;

namespace ItemWrapper.Generator {
	public enum RealmType {
		None,
		Universe,
		Multiverse,
	}
}
