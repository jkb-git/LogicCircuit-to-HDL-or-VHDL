﻿using System;

namespace LogicCircuit {
	public enum MemoryMapKeyboard {
		Disabled,
		Hack,
		Other
	}
}
